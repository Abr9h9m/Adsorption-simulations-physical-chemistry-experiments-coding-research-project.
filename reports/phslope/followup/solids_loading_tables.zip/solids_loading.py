"""Solids-normalised edge and sorbate-to-mineral loading regimes (EXPLORATORY, 2026-10-13).
Response available: fraction sorbed f = Sorbed/Total sorbate added (NOT corrected for solids).
Derived (assuming mass balance Aq = Total - Sorbed):  K = Sorbed/Aq = f/(1-f)  (dimensionless);  Kd = K / S  (L/g), S = solids g/L.
"""
import sys, json, warnings
import numpy as np, pandas as pd, statsmodels.api as sm
warnings.filterwarnings("ignore")
B = "/mnt/user-data/uploads/Mineral Fingerprinting/"
OUT = sys.argv[1]
t = pd.read_csv(B + "reports/phslope/stage1/curve_table.csv")
obs = pd.read_csv(B + "export/observations.csv", usecols=["curve_id", "pH", "response"]).dropna()
obs = obs[(obs.pH >= 0) & (obs.pH <= 14)]
c = t[t["shape"].isin(["rising", "falling"]) & (t.solids_g_L > 0) & (t.total_sorbate_mol_L > 0)].copy()
print("rising/falling curves with solids and total sorbate:", len(c), " core:", int(c.in_core_library.sum()))
by = {k: g for k, g in obs.groupby("curve_id")}

rows = []
for _, r in c.iterrows():
    g = by.get(r.curve_id)
    if g is None:
        continue
    f = g.response.to_numpy(); p = g.pH.to_numpy()
    m = (f > 0.03) & (f < 0.97)
    if m.sum() < 3 or np.ptp(p[m]) < 0.5:
        continue
    lk = np.log10(f[m] / (1 - f[m]))
    X = sm.add_constant(p[m]); fit = sm.OLS(lk, X).fit()
    a, b = fit.params
    if abs(b) < 1e-6:
        continue
    r2 = fit.rsquared
    ls = np.log10(r.solids_g_L)
    rows.append(dict(curve_id=r.curve_id, reference=r.reference, mineral=r.mineral, sorbate=r.sorbate, shape=r["shape"],
                     in_core=bool(r.in_core_library), n_mid=int(m.sum()), pH_lo=p[m].min(), pH_hi=p[m].max(),
                     a=a, b=b, r2=r2, log_S=ls, log_total=np.log10(r.total_sorbate_mol_L),
                     pH_native=-a / b, pH_S1=(ls - a) / b))
D = pd.DataFrame(rows)
D["ok_dir"] = np.where(D["shape"] == "rising", D.b > 0, D.b < 0)
D["in_range"] = (D.pH_native > D.pH_lo - 0.5) & (D.pH_native < D.pH_hi + 0.5) & (D.pH_S1 > D.pH_lo - 1.5) & (D.pH_S1 < D.pH_hi + 1.5)
D["log_L"] = D.log_total - D.log_S                       # mol sorbate per g solid
D["grp"] = D.mineral + "|" + D.sorbate + "|" + D["shape"]
Dq = D[D.ok_dir & (D.r2 >= 0.5) & D.in_range].copy()
Dq = Dq[Dq.groupby("grp").reference.transform("nunique") >= 2]
print(f"usable curves for the Kd-space line fit: {len(D)}; direction-consistent, R2>=0.5, crossing near data: {int((D.ok_dir & (D.r2>=0.5) & D.in_range).sum())}; in groups with >=2 papers: {len(Dq)} ({Dq.grp.nunique()} groups, {Dq.reference.nunique()} papers)", flush=True)
D.to_csv(f"{OUT}/kd_line_fits_all.csv", index=False)

# ---------- A. does solids-normalising shrink disagreement between papers? ----------
def spread(df, col):
    sd = df.groupby("grp")[col].std()
    rng = []
    for _, g in df.groupby("grp"):
        v = g.groupby("reference")[col].mean().to_numpy()
        for i in range(len(v)):
            for j in range(i + 1, len(v)):
                rng.append(abs(v[i] - v[j]))
    return dict(median_within_group_sd=float(sd.median()), mean_within_group_sd=float(sd.mean()),
                median_paper_to_paper_diff=float(np.median(rng)), n_pairs=len(rng))
resA = {"native edge (f = 0.5 at the solids actually used)": spread(Dq, "pH_native"),
        "edge normalised to 1 g/L solids": spread(Dq, "pH_S1")}
A = pd.DataFrame(resA).T.round(3); A.to_csv(f"{OUT}/A_edge_spread.csv"); print(A.to_string(), flush=True)
# same, only groups where solids actually vary across papers (spread in log S >= 0.5 decade)
vary = Dq.groupby("grp").log_S.transform(lambda s: s.max() - s.min()) >= 0.5
Av = pd.DataFrame({"native": spread(Dq[vary], "pH_native"), "normalised to 1 g/L": spread(Dq[vary], "pH_S1")}).T.round(3)
Av["n_curves"] = int(vary.sum()); Av["n_groups"] = Dq[vary].grp.nunique()
Av.to_csv(f"{OUT}/A_edge_spread_solids_vary.csv"); print(Av.to_string(), flush=True)

# solids coefficient before / after, by direction (group-centred, clustered by paper)
rowsA = []
for col in ["pH_native", "pH_S1"]:
    for s, d in list(Dq.groupby("shape")) + [("all", Dq)]:
        d = d.copy(); d["e"] = d[col] - d.groupby("grp")[col].transform("mean"); d["x"] = d.log_S - d.groupby("grp").log_S.transform("mean")
        if d.x.std() == 0: continue
        r = sm.OLS(d.e, sm.add_constant(d.x)).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(d.reference)[0]})
        ci = r.conf_int().iloc[1]
        rowsA.append(dict(edge=col, direction=s, n=len(d), groups=d.grp.nunique(), papers=d.reference.nunique(),
                          ph_per_decade_of_solids=round(r.params.iloc[1], 3), ci_lo=round(ci[0], 3), ci_hi=round(ci[1], 3), p=round(r.pvalues.iloc[1], 4)))
SA = pd.DataFrame(rowsA); SA.to_csv(f"{OUT}/A_solids_coefficient.csv", index=False); print(SA.to_string(), flush=True)

# slope of log10 K vs pH, by sorbate
SL = Dq.assign(absb=Dq.b.abs()).groupby(["sorbate", "shape"]).absb.agg(["count", "median"]).query("count>=8").round(2).sort_values("count", ascending=False)
SL.columns = ["n_curves", "median_|dlogK/dpH|"]; SL.to_csv(f"{OUT}/A_slope_by_sorbate.csv"); print(SL.head(12).to_string(), flush=True)
# exchange: expected edge shift from a 10x solids change = 1/|b| pH units (check against the fitted coefficient)
print("median expected shift per decade of solids = median(1/|b|):", round((1 / Dq.b.abs()).median(), 2), flush=True)

# ---------- B. loading regime: log Kd (L/g) at a fixed pH vs log(sorbate per g solid) ----------
ref = Dq.groupby("grp").pH_native.median().rename("pH_ref")
Dl = Dq.join(ref, on="grp")
Dl = Dl[(Dl.pH_ref >= Dl.pH_lo - 0.25) & (Dl.pH_ref <= Dl.pH_hi + 0.25)].copy()      # evaluate only inside the fitted pH range
Dl["logKd"] = Dl.a + Dl.b * Dl.pH_ref - Dl.log_S                                        # log10 Kd, L/g, at the group's reference pH
Dl["y"] = Dl.logKd - Dl.groupby("grp").logKd.transform("mean"); Dl["x"] = Dl.log_L - Dl.groupby("grp").log_L.transform("mean")
Dl = Dl[Dl.groupby("grp").log_L.transform(lambda s: s.max() - s.min()) >= 0.5]      # groups where loading actually varies
print(f"\nB: {len(Dl)} curves, {Dl.grp.nunique()} groups, {Dl.reference.nunique()} papers; loading range (log10 mol/g): {Dl.log_L.min():.1f} to {Dl.log_L.max():.1f}", flush=True)

def clustered(y, X, d):
    r = sm.OLS(y, X).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(d.reference)[0]}); return r

rB = []
for s, d in [("all", Dl)] + list(Dl.groupby("shape")):
    r = clustered(d.y, sm.add_constant(d.x), d); ci = r.conf_int().iloc[1]
    rB.append(dict(set=s, n=len(d), groups=d.grp.nunique(), papers=d.reference.nunique(), dlogKd_per_decade_loading=round(r.params.iloc[1], 3),
                   ci_lo=round(ci[0], 3), ci_hi=round(ci[1], 3), p=round(r.pvalues.iloc[1], 4)))
# within-paper version
dp = Dl.assign(pg=Dl.reference + "|" + Dl.grp)
dp = dp[dp.groupby("pg").log_L.transform(lambda s: s.max() - s.min()) >= 0.3].copy()
dp["y2"] = dp.logKd - dp.groupby("pg").logKd.transform("mean"); dp["x2"] = dp.log_L - dp.groupby("pg").log_L.transform("mean")
if len(dp) > 20:
    r = clustered(dp.y2, sm.add_constant(dp.x2), dp); ci = r.conf_int().iloc[1]
    rB.append(dict(set="within-paper only", n=len(dp), groups=dp.pg.nunique(), papers=dp.reference.nunique(), dlogKd_per_decade_loading=round(r.params.iloc[1], 3),
                   ci_lo=round(ci[0], 3), ci_hi=round(ci[1], 3), p=round(r.pvalues.iloc[1], 4)))
RB = pd.DataFrame(rB); RB.to_csv(f"{OUT}/B_loading_slope.csv", index=False); print(RB.to_string(), flush=True)

# piecewise-linear break search (group-centred x measured on the raw log_L scale)
def pw_rss(d, bp):
    h = np.maximum(d.log_L - bp, 0.0)
    h = h - h.groupby(d.grp).transform("mean")
    X = np.column_stack([d.x, h]); beta, res, *_ = np.linalg.lstsq(X, d.y, rcond=None)
    return float(((d.y - X @ beta) ** 2).sum()), beta
lin_rss = float(((d.y - np.linalg.lstsq(d[["x"]].to_numpy(), d.y, rcond=None)[0][0] * d.x) ** 2).sum()) if False else None
d = Dl
beta0 = np.linalg.lstsq(d[["x"]].to_numpy(), d.y.to_numpy(), rcond=None)[0]
rss0 = float(((d.y.to_numpy() - d[["x"]].to_numpy() @ beta0) ** 2).sum())
cands = np.linspace(d.log_L.quantile(0.1), d.log_L.quantile(0.9), 41)
fits = [(bp, *pw_rss(d, bp)) for bp in cands]
bp, rss1, beta1 = min(fits, key=lambda z: z[1])
n = len(d); aic0 = n * np.log(rss0 / n) + 2 * 1; aic1 = n * np.log(rss1 / n) + 2 * 3
# bootstrap by paper for the breakpoint
rng = np.random.default_rng(7); refs = d.reference.unique(); bps = []
for _ in range(100):
    pick = rng.choice(refs, len(refs), replace=True)
    dd = pd.concat([d[d.reference == r_].assign(grp=d.grp + f"#{i}") for i, r_ in enumerate(pick)])
    dd["x"] = dd.log_L - dd.groupby("grp").log_L.transform("mean"); dd["y"] = dd.logKd - dd.groupby("grp").logKd.transform("mean")
    bps.append(min(((b_, pw_rss(dd, b_)[0]) for b_ in cands), key=lambda z: z[1])[0])
PW = pd.DataFrame([dict(breakpoint_log10_mol_per_g=round(bp, 2), bp_ci_lo=round(np.percentile(bps, 5), 2), bp_ci_hi=round(np.percentile(bps, 95), 2),
                        slope_below=round(beta1[0], 3), slope_above=round(beta1[0] + beta1[1], 3), rss_linear=round(rss0, 2), rss_piecewise=round(rss1, 2),
                        AIC_linear=round(aic0, 1), AIC_piecewise=round(aic1, 1), n=n)])
PW.to_csv(f"{OUT}/B_piecewise.csv", index=False); print(PW.T.to_string(), flush=True)

# binned view
edges = np.array([-9.5, -8, -7, -6.5, -6, -5.5, -5, -4, -2])
Dl["bin"] = pd.cut(Dl.log_L, edges)
BN = Dl.groupby("bin", observed=True).agg(n=("y", "size"), groups=("grp", "nunique"), mean_logKd_centred=("y", "mean"), se=("y", lambda s: s.std() / np.sqrt(len(s)))).round(3)
BN.to_csv(f"{OUT}/B_binned_logKd.csv"); print(BN.to_string(), flush=True)

# regime label per curve: low / transition / high loading relative to breakpoint (+/- 0.5 decade)
Dl["regime"] = np.where(Dl.log_L < bp - 0.5, "low loading (linear)", np.where(Dl.log_L > bp + 0.5, "high loading (saturating)", "transition"))
Dl[["curve_id", "reference", "mineral", "sorbate", "shape", "log_S", "log_total", "log_L", "regime", "logKd", "pH_native", "pH_S1", "b"]].to_csv(f"{OUT}/B_curve_regimes.csv", index=False)
print(Dl.regime.value_counts().to_dict(), flush=True)

# height (plateau) vs loading: p95 of f
hp = obs.groupby("curve_id").response.quantile(0.95).rename("plateau")
Dh = Dl.join(hp, on="curve_id").dropna(subset=["plateau"])
Dh["yh"] = Dh.plateau - Dh.groupby("grp").plateau.transform("mean")
rh = []
for s, dd in [("all", Dh)] + list(Dh.groupby("shape")):
    r = clustered(dd.yh, sm.add_constant(dd.x), dd); ci = r.conf_int().iloc[1]
    rh.append(dict(set=s, n=len(dd), plateau_change_per_decade_loading=round(r.params.iloc[1], 3), ci_lo=round(ci[0], 3), ci_hi=round(ci[1], 3), p=round(r.pvalues.iloc[1], 4)))
RH = pd.DataFrame(rh); RH.to_csv(f"{OUT}/B_plateau_vs_loading.csv", index=False); print(RH.to_string(), flush=True)

# edge in solids-normalised space vs loading (does the loading change the edge once solids are handled?)
Dl["e1"] = Dl.pH_S1 - Dl.groupby("grp").pH_S1.transform("mean")
re = []
for s, dd in [("all", Dl)] + list(Dl.groupby("shape")):
    r = clustered(dd.e1, sm.add_constant(dd.x), dd); ci = r.conf_int().iloc[1]
    re.append(dict(set=s, n=len(dd), edge_shift_pH_per_decade_loading=round(r.params.iloc[1], 3), ci_lo=round(ci[0], 3), ci_hi=round(ci[1], 3), p=round(r.pvalues.iloc[1], 4)))
RE = pd.DataFrame(re); RE.to_csv(f"{OUT}/B_edge_vs_loading.csv", index=False); print(RE.to_string(), flush=True)
json.dump(dict(n_fit=len(D), n_Dq=len(Dq), n_Dl=len(Dl), breakpoint=bp), open(f"{OUT}/RUN_INFO.json", "w"))
