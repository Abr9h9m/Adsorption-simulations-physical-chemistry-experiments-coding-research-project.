"""Exploratory follow-up to the pooled-pair comparison (2026-10-13).
Part 1  cap on number of papers per pool
Part 2  pool only papers whose single-curve edges agree
Part 3  covariate analysis: what goes with curve-to-curve differences
Part 4  held-out test: does matching on conditions predict a new paper's edge better?
All EXPLORATORY. Seeds fixed.
"""
import sys, re, json, warnings
import numpy as np, pandas as pd
from scipy.optimize import least_squares
warnings.filterwarnings("ignore")

B = "/mnt/user-data/uploads/Mineral Fingerprinting/"
OUT = sys.argv[1] if len(sys.argv) > 1 else "."
RNG = np.random.default_rng(20261013)
DRAWS, BOOT = 12, 30

t = pd.read_csv(B + "reports/phslope/stage1/curve_table.csv")
obs = pd.read_csv(B + "export/observations.csv", usecols=["curve_id", "pH", "response"]).dropna()
obs = obs[(obs.pH >= 0) & (obs.pH <= 14)]
obs_by = {k: g[["pH", "response"]].to_numpy() for k, g in obs.groupby("curve_id")}


# ---------- logistic fit ----------
def logi(p, th):
    lo, hi, p50, w = th
    return lo + (hi - lo) / (1 + np.exp(-(p - p50) / w))


def fit_logistic(pH, y):
    pmin, pmax = pH.min(), pH.max()
    best = None
    ylo, yhi = np.percentile(y, 10), np.percentile(y, 90)
    for p50 in np.linspace(pmin, pmax, 7):
        for (lo, hi) in [(ylo, yhi), (yhi, ylo)]:
            for w in (0.3, 0.8):
                try:
                    r = least_squares(lambda th: logi(pH, th) - y, [lo, hi, p50, w],
                                      bounds=([-0.1, -0.1, pmin - 1, 0.05], [1.1, 1.1, pmax + 1, 3.0]), max_nfev=200)
                except Exception:
                    continue
                if best is None or r.cost < best.cost:
                    best = r
    return None if best is None else best.x


def pooled_metrics(pts, refs, single_w, single_p50, boot=False):
    pH, y = pts[:, 0], pts[:, 1]
    th = fit_logistic(pH, y)
    if th is None:
        return None
    lo, hi, p50, w = th
    res = y - logi(pH, th)
    rmse = np.sqrt(np.mean(res ** 2))
    # share of residual sum of squares that sits in per-paper mean offsets
    ss = (res ** 2).sum()
    ssb = sum(len(res[refs == r]) * res[refs == r].mean() ** 2 for r in np.unique(refs))
    bracket = ((pH < p50 - 0.5).any()) and ((pH > p50 + 0.5).any())
    at_bound = (w <= 0.0501) or (w >= 2.99)
    out = dict(w=w, p50=p50, height=hi - lo, rmse=rmse, between_paper_share=ssb / ss if ss > 0 else np.nan,
               bracketed=bracket, at_bound=at_bound,
               width_ratio=w / single_w, edge_shift=p50 - single_p50)
    out["qc_proxy"] = bool(bracket and not at_bound and rmse < 0.10)
    if boot:
        ur = np.unique(refs)
        if len(ur) >= 3:
            ps = []
            for _ in range(BOOT):
                pick = RNG.choice(ur, len(ur), replace=True)
                m = np.concatenate([np.where(refs == r)[0] for r in pick])
                th2 = fit_logistic(pH[m], y[m])
                if th2 is not None:
                    ps.append(th2[2])
            if len(ps) >= 15:
                out["p50_ci_width"] = np.percentile(ps, 97.5) - np.percentile(ps, 2.5)
    return out


# ---------- groups ----------
e = t[t["shape"].isin(["rising", "falling"]) & t.logistic_p50.notna() & t.logistic_w.notna()].copy()
e = e[(e.logistic_w > 0.0501) & (e.logistic_w < 2.99) & e.curve_id.isin(obs_by)]
groups = {k: g for k, g in e.groupby(["mineral", "sorbate", "shape"]) if g.reference.nunique() >= 4}
print(f"{len(groups)} pair-direction groups with >=4 papers; {sum(len(g) for g in groups.values())} curves", flush=True)


def build(g, papers):
    sub = g[g.reference.isin(papers)]
    pts = np.vstack([obs_by[c] for c in sub.curve_id])
    refs = np.concatenate([[r] * len(obs_by[c]) for c, r in zip(sub.curve_id, sub.reference)])
    return pts, refs, sub.logistic_w.median(), sub.logistic_p50.median(), sub


rows = []
for gi, (key, g) in enumerate(groups.items()):
    papers = sorted(g.reference.unique())
    pe = g.groupby("reference").logistic_p50.median()          # paper-level edge
    tag = dict(mineral=key[0], sorbate=key[1], direction=key[2], n_papers=len(papers))

    def add(cond, papers_used, boot=False, draw=0):
        pts, refs, sw, sp, sub = build(g, papers_used)
        m = pooled_metrics(pts, refs, sw, sp, boot)
        if m is None:
            return
        m.update(tag, condition=cond, k=len(papers_used), n_curves=len(sub), draw=draw,
                 edge_range=float(pe[list(papers_used)].max() - pe[list(papers_used)].min()))
        rows.append(m)

    add("all papers", papers, boot=True)
    for k in (2, 3, 4):
        if len(papers) <= k:
            continue
        for d in range(DRAWS):
            add(f"random {k} papers", list(RNG.choice(papers, k, replace=False)), boot=(k >= 3 and d < 3), draw=d)
        s = pe.sort_values()
        vals = s.values
        spans = [(vals[i + k - 1] - vals[i], i) for i in range(len(vals) - k + 1)]
        i = min(spans)[1]
        add(f"tightest {k} by edge", list(s.index[i:i + k]), boot=(k >= 3))
        # widest k: extremes
        idx = np.unique(np.linspace(0, len(vals) - 1, k).round().astype(int))
        if len(idx) == k:
            add(f"widest {k} by edge", list(s.index[idx]), boot=(k >= 3))
    med = pe.median()
    for delta in (0.5, 1.0):
        keep = list(pe.index[(pe - med).abs() <= delta])
        if len(keep) >= 2 and len(keep) < len(papers):
            add(f"within {delta} pH of group median edge", keep, boot=(len(keep) >= 3))
    print(f"  [{gi+1}/{len(groups)}] {key} papers={len(papers)}", flush=True)

P1 = pd.DataFrame(rows)
P1.to_csv(f"{OUT}/part12_pooled_fits.csv", index=False)

# ---------- summaries for parts 1 and 2 ----------
def agg(df):
    return df.groupby("condition").agg(
        n_fits=("w", "size"), n_groups=("mineral", lambda s: len(set(zip(s, df.loc[s.index, "sorbate"], df.loc[s.index, "direction"])))),
        median_papers=("k", "median"), median_edge_range=("edge_range", "median"),
        median_width_ratio=("width_ratio", "median"), q25_wr=("width_ratio", lambda s: s.quantile(.25)),
        q75_wr=("width_ratio", lambda s: s.quantile(.75)),
        share_wr_above_1_5=("width_ratio", lambda s: (s > 1.5).mean()),
        median_abs_edge_shift=("edge_shift", lambda s: s.abs().median()),
        median_between_paper_share=("between_paper_share", "median"),
        qc_proxy_pass=("qc_proxy", "mean"),
        median_p50_ci_width=("p50_ci_width", "median"), n_ci=("p50_ci_width", "count")).round(3)

S = agg(P1)
S.to_csv(f"{OUT}/part12_summary.csv")
print(S.to_string(), flush=True)

# same-group matched comparison: for each group, all vs each condition (paired)
paired = []
base = P1[P1.condition == "all papers"].set_index(["mineral", "sorbate", "direction"])
for cond, d in P1[P1.condition != "all papers"].groupby("condition"):
    dd = d.groupby(["mineral", "sorbate", "direction"])[["width_ratio", "between_paper_share", "qc_proxy"]].mean()
    j = dd.join(base[["width_ratio", "between_paper_share", "qc_proxy"]], rsuffix="_all", how="inner")
    paired.append(dict(condition=cond, n_groups=len(j),
                       median_wr=j.width_ratio.median(), median_wr_all=j.width_ratio_all.median(),
                       median_diff=(j.width_ratio - j.width_ratio_all).median(),
                       groups_better=int((j.width_ratio < j.width_ratio_all).sum()),
                       qc=j.qc_proxy.mean(), qc_all=j.qc_proxy_all.mean()))
PD = pd.DataFrame(paired).round(3)
PD.to_csv(f"{OUT}/part12_paired_vs_all.csv", index=False)
print(PD.to_string(), flush=True)

# ---------- Part 3 and 4: covariates ----------
c = t[t["shape"].isin(["rising", "falling"]) & t.in_core_library].copy()
c["logI"] = np.log10(c.ionic_strength.where(c.ionic_strength > 0))
c["log_total"] = np.log10(c.total_sorbate_mol_L.where(c.total_sorbate_mol_L > 0))
c["log_solids"] = np.log10(c.solids_g_L.where(c.solids_g_L > 0))
c["log_loading"] = c.log_total - c.log_solids                          # sorbate per gram solid
c["co2"] = c.co2_present.astype(float)
c["cosol"] = c.has_cosolute.astype(float)
c["temp_c"] = c.temp
c["sites"] = c.mineralsites
yr = c.reference.str.extract(r"(\d{2})")[0].astype(float)
c["ref_year"] = np.where(yr < 30, 2000 + yr, 1900 + yr)
c["pH_span_c"] = c.pH_span
def bg(sig):
    s = str(sig)
    for k, v in (("N(+5)", "nitrate"), ("Cl(+7)", "perchlorate"), ("Cl(-1)", "chloride"), ("S(+6)", "sulfate")):
        if k in s:
            return v
    return "other"
c["background"] = c.electrolyte_sig.map(bg)
c["edge"] = c.logistic_p50
c["grp"] = c.mineral + "|" + c.sorbate + "|" + c["shape"]
cg = c.groupby("grp").reference.transform("nunique")
c2 = c[cg >= 2].copy()
print(f"\nPart 3/4: {len(c2)} curves in {c2.grp.nunique()} groups with >=2 papers; {c2.reference.nunique()} papers", flush=True)

num = ["log_solids", "log_total", "log_loading", "logI", "temp_c", "sites", "co2", "cosol", "ref_year", "pH_span_c"]
# 3a: within-group effect of each covariate on edge (centered in group), cluster-robust by paper
import statsmodels.api as sm
rows3 = []
c2["edge_c"] = c2.edge - c2.groupby("grp").edge.transform("mean")
for v in num:
    d = c2[["edge_c", v, "grp", "reference"]].dropna()
    d = d.assign(vc=d[v] - d.groupby("grp")[v].transform("mean"))
    d = d[d.groupby("grp")[v].transform("count") >= 2]
    if d.vc.std() == 0 or len(d) < 30:
        rows3.append(dict(covariate=v, n=len(d), note="no within-group variation")); continue
    z = d.vc / d.vc.std()
    r = sm.OLS(d.edge_c, sm.add_constant(z)).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(d.reference)[0]})
    ci = r.conf_int().iloc[1]
    rows3.append(dict(covariate=v, n=len(d), sd_within_group=round(d.vc.std(), 3),
                      ph_per_sd=round(r.params.iloc[1], 3), ci_lo=round(ci[0], 3), ci_hi=round(ci[1], 3),
                      p=round(r.pvalues.iloc[1], 4), within_R2=round(r.rsquared, 4)))
# categorical background anion: share of within-group variance
d = c2.assign(bgc=c2.background)
r = sm.OLS(d.edge_c, pd.get_dummies(d.bgc, drop_first=True).astype(float).assign(const=1.0)).fit(
    cov_type="cluster", cov_kwds={"groups": pd.factorize(d.reference)[0]})
rows3.append(dict(covariate="background anion (4 levels)", n=len(d), within_R2=round(r.rsquared, 4), p=round(float(r.f_pvalue), 4)))
P3a = pd.DataFrame(rows3); P3a.to_csv(f"{OUT}/part3a_within_group_covariates.csv", index=False)
print(P3a.to_string(), flush=True)

# joint model (complete cases)
jv = ["log_solids", "log_total", "logI", "co2", "cosol", "ref_year"]
d = c2[["edge_c", "grp", "reference"] + jv].dropna()
d = d.assign(**{v: d[v] - d.groupby("grp")[v].transform("mean") for v in jv})
d[jv] = d[jv] / d[jv].std().replace(0, 1)
rj = sm.OLS(d.edge_c, sm.add_constant(d[jv])).fit(cov_type="cluster", cov_kwds={"groups": pd.factorize(d.reference)[0]})
P3j = pd.DataFrame({"ph_per_sd": rj.params.round(3), "ci_lo": rj.conf_int()[0].round(3), "ci_hi": rj.conf_int()[1].round(3),
                    "p": rj.pvalues.round(4)}); P3j.attrs["n"] = len(d); P3j.attrs["R2"] = rj.rsquared
P3j.to_csv(f"{OUT}/part3a_joint_model.csv")
print(P3j.to_string(), f"\nn={len(d)} R2={rj.rsquared:.3f}", flush=True)

# 3b: curve pairs from different papers within group: similar vs dissimilar
from scipy.stats import mannwhitneyu
pr = []
for gname, g in c2.groupby("grp"):
    idx = g.index.to_list()
    for i in range(len(idx)):
        for j in range(i + 1, len(idx)):
            a, b = g.loc[idx[i]], g.loc[idx[j]]
            if a.reference == b.reference:
                continue
            pr.append(dict(grp=gname, d_edge=abs(a.edge - b.edge),
                           **{f"d_{v}": abs(a[v] - b[v]) for v in num},
                           same_background=float(a.background == b.background)))
PR = pd.DataFrame(pr)
PR["cls"] = np.where(PR.d_edge < 0.5, "similar (<0.5 pH)", np.where(PR.d_edge > 1.5, "different (>1.5 pH)", "middle"))
print(f"\n{len(PR)} cross-paper curve pairs: {PR.cls.value_counts().to_dict()}", flush=True)
rows3b = []
for v in [f"d_{x}" for x in num] + ["same_background"]:
    s, dff = PR[PR.cls.str.startswith("similar")][v].dropna(), PR[PR.cls.str.startswith("different")][v].dropna()
    if len(s) < 20 or len(dff) < 20:
        continue
    u = mannwhitneyu(s, dff)
    auc = u.statistic / (len(s) * len(dff))             # P(similar value > different value)
    rows3b.append(dict(covariate=v, n_similar=len(s), n_different=len(dff), median_similar=round(s.median(), 3),
                       median_different=round(dff.median(), 3), auc_similar_gt_different=round(auc, 3), p=round(u.pvalue, 5)))
P3b = pd.DataFrame(rows3b); P3b.to_csv(f"{OUT}/part3b_similar_vs_different_pairs.csv", index=False)
print(P3b.to_string(), flush=True)
# Spearman: |d_edge| vs each |d_cov|
from scipy.stats import spearmanr
sp = []
for v in [f"d_{x}" for x in num]:
    d = PR[["d_edge", v]].dropna()
    r_, p_ = spearmanr(d.d_edge, d[v]); sp.append(dict(covariate=v, n=len(d), spearman=round(r_, 3), p=round(p_, 5)))
P3c = pd.DataFrame(sp); P3c.to_csv(f"{OUT}/part3c_spearman_edge_diff.csv", index=False)
print(P3c.to_string(), flush=True)

# Part 4: leave-one-paper-out; predict edge from other papers of same group
feat = ["log_solids", "log_total", "logI"]
sd = {v: c2[v].std() for v in feat}
pred_rows = []
for i, r in c2.iterrows():
    o = c2[(c2.grp == r.grp) & (c2.reference != r.reference)]
    if o.empty:
        continue
    allmean = o.groupby("reference").edge.mean().mean()
    # standardized distance on available features + flags
    dist = np.zeros(len(o)); ok = np.ones(len(o), bool)
    for v in feat:
        dv = (o[v] - r[v]).abs() / sd[v]
        dist += dv.fillna(1.5).to_numpy()
    dist += 1.0 * (o.co2 != r.co2).to_numpy() + 1.0 * (o.cosol != r.cosol).to_numpy() + 0.5 * (o.background != r.background).to_numpy()
    order = np.argsort(dist)
    nn1 = o.edge.to_numpy()[order[0]]
    nn3 = o.edge.to_numpy()[order[:3]].mean()
    # hard conditions match
    m = ((o.log_solids - r.log_solids).abs() < 0.5).fillna(False) & ((o.log_total - r.log_total).abs() < 1.0).fillna(False) \
        & (o.co2 == r.co2) & (o.cosol == r.cosol)
    matched = o.edge[m].mean() if m.sum() else np.nan
    # nearest in "similar conditions" with paper weights equal
    pred_rows.append(dict(curve_id=r.curve_id, grp=r.grp, obs=r.edge, n_other_papers=o.reference.nunique(),
                          all_other=allmean, nearest1=nn1, nearest3=nn3, matched=matched, n_matched=int(m.sum())))
P4 = pd.DataFrame(pred_rows)
P4["matched_fb"] = P4.matched.fillna(P4.all_other)
P4.to_csv(f"{OUT}/part4_heldout_predictions.csv", index=False)
res = []
for name in ["all_other", "nearest1", "nearest3", "matched_fb"]:
    err = (P4[name] - P4.obs).abs()
    res.append(dict(predictor=name, n=len(P4), median_abs_err=round(err.median(), 3), mean_abs_err=round(err.mean(), 3),
                    rmse=round(np.sqrt(((P4[name] - P4.obs) ** 2).mean()), 3), share_within_0_5=round((err < 0.5).mean(), 3),
                    share_within_1=round((err < 1).mean(), 3)))
mm = P4.dropna(subset=["matched"])
for name in ["all_other", "matched"]:
    err = (mm[name] - mm.obs).abs()
    res.append(dict(predictor=f"{name} (only curves with a conditions-matched paper)", n=len(mm), median_abs_err=round(err.median(), 3),
                    mean_abs_err=round(err.mean(), 3), rmse=round(np.sqrt(((mm[name] - mm.obs) ** 2).mean()), 3),
                    share_within_0_5=round((err < 0.5).mean(), 3), share_within_1=round((err < 1).mean(), 3)))
P4s = pd.DataFrame(res); P4s.to_csv(f"{OUT}/part4_summary.csv", index=False)
print(P4s.to_string(), flush=True)
json.dump(dict(draws=DRAWS, boot=BOOT, n_groups_part12=len(groups), n_curves_part34=len(c2)), open(f"{OUT}/RUN_INFO.json", "w"))
